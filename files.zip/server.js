const express = require('express');
const cors = require('cors');
const Anthropic = require('@anthropic-ai/sdk');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const nodemailer = require('nodemailer');
const PDFDocument = require('pdfkit');

const app = express();

app.use(cors());
app.use(express.json());
app.use('/webhook', express.raw({ type: 'application/json' }));

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

// Email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// Generate obituary using Claude
async function generateObituary(formData, count = 1) {
  const prompt = `Write ${count} professional, heartfelt obituar${count > 1 ? 'ies' : 'y'} based on this information:

Name: ${formData.fullName}
Birth Date: ${formData.birthDate}
Death Date: ${formData.deathDate}
Personality: ${formData.personality || 'Not provided'}
Hobbies: ${formData.hobbies || 'Not provided'}
Achievements: ${formData.achievements || 'Not provided'}
Family: ${formData.family || 'Not provided'}
Tone: ${formData.tone || 'heartfelt'}

${count > 1 ? `Please provide ${count} different versions with varying styles and lengths.` : ''}

Write in a ${formData.tone || 'heartfelt'} tone. Make it meaningful and memorable.`;

  const message = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2000,
    messages: [{ role: 'user', content: prompt }]
  });

  const text = message.content[0].text;
  
  if (count === 1) {
    return [text];
  }
  
  return text.split(/\n\n---\n\n|\n\nVersion \d+:/i).filter(t => t.trim());
}

// Generate PDF
function generatePDF(obituaries, formData) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument();
    const chunks = [];
    
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    
    doc.fontSize(20).text('In Loving Memory', { align: 'center' });
    doc.moveDown();
    doc.fontSize(16).text(formData.fullName, { align: 'center' });
    doc.fontSize(12).text(`${formData.birthDate} - ${formData.deathDate}`, { align: 'center' });
    doc.moveDown(2);
    
    obituaries.forEach((obit, index) => {
      if (index > 0) {
        doc.addPage();
        doc.fontSize(14).text(`Version ${index + 1}`, { align: 'center' });
        doc.moveDown();
      }
      doc.fontSize(11).text(obit, { align: 'justify' });
    });
    
    doc.end();
  });
}

// Health check endpoint
app.get('/', (req, res) => {
  res.json({ status: 'Obitura Backend Running', timestamp: new Date() });
});

// Create Stripe Checkout Session with form data
app.post('/create-checkout', async (req, res) => {
  try {
    const { formData, priceId } = req.body;
    
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price: priceId,
        quantity: 1,
      }],
      mode: 'payment',
      success_url: 'https://obitura.com/success',
      cancel_url: 'https://obitura.com/',
      customer_email: formData.email,
      metadata: {
        formData: JSON.stringify(formData)
      }
    });
    
    res.json({ url: session.url });
  } catch (error) {
    console.error('Error creating checkout session:', error);
    res.status(500).json({ error: error.message });
  }
});

// Stripe Webhook
app.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const formData = JSON.parse(session.metadata.formData);
      
      // Determine package type
      let count = 1;
      if (session.amount_total === 4400) count = 3; // Deluxe
      if (session.amount_total === 6200) count = 5; // Legacy
      
      // Generate obituaries
      const obituaries = await generateObituary(formData, count);
      
      // Generate PDF
      const pdfBuffer = await generatePDF(obituaries, formData);
      
      // Send email
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: formData.email,
        subject: `Your ${count > 1 ? count + ' ' : ''}Obituar${count > 1 ? 'ies' : 'y'} for ${formData.fullName}`,
        text: `Thank you for using Obitura. Please find your ${count > 1 ? count + ' obituaries' : 'obituary'} attached.`,
        html: `
          <h2>Your Obituar${count > 1 ? 'ies' : 'y'}</h2>
          <p>Thank you for trusting Obitura to help honor ${formData.fullName}.</p>
          ${obituaries.map((obit, i) => `
            ${count > 1 ? `<h3>Version ${i + 1}</h3>` : ''}
            <p style="white-space: pre-wrap;">${obit}</p>
            ${i < obituaries.length - 1 ? '<hr>' : ''}
          `).join('')}
        `,
        attachments: [{
          filename: `${formData.fullName.replace(/\s+/g, '_')}_Obituary.pdf`,
          content: pdfBuffer
        }]
      });
      
      console.log('Obituary sent successfully to:', formData.email);
    }
    
    res.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(400).send(`Webhook Error: ${error.message}`);
  }
});

// Test endpoint to verify AI generation
app.post('/test-generate', async (req, res) => {
  try {
    const obituaries = await generateObituary(req.body, 1);
    res.json({ success: true, obituary: obituaries[0] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Export for Vercel
module.exports = app;
